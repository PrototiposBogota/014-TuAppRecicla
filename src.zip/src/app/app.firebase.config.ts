export const FIREBASE_CONFIG={
    apiKey: "AIzaSyC-cSGyOdqlcRJSHzOh4D7g-elDhq7QTHM",
    authDomain: "tu-app-recicla.firebaseapp.com",
    databaseURL: "https://tu-app-recicla.firebaseio.com",
    projectId: "tu-app-recicla",
    storageBucket: "tu-app-recicla.appspot.com",
    messagingSenderId: "631980406768"
};