import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

declare var google: any;

/**
 * Generated class for the CentrosAcopioPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@IonicPage()
@Component({
  selector: 'page-centros-acopio',
  templateUrl: 'centros-acopio.html',
})
export class CentrosAcopioPage {
  @ViewChild('map') mapRef: ElementRef;
  map: any;
  listMarker=[
    {lat: 41.939670,long: -87.655167,info: "Info1"},
    {lat: 41.976816,long: -87.659916,info: "Info1"},
    {lat: 42.002707,long: -87.661236,info: "Info1"}
    
  ];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CentrosAcopioPage');
    this.showMap();
  }

  showMap(){
    const location=new google.maps.LatLng(51.507351,-0.127758);
    const options = {
      center: location,
      zoom: 20,
      mapTypeId: 'roadmap',
    }
    this.map=new google.maps.Map(this.mapRef.nativeElement,options);
    
   /* for(let i=0;i<this.listMarker.length;i++){
      let location_=new google.maps.LatLng(this.listMarker[i].lat,this.listMarker[i].long);
      
    }
*/
   this.addMarker(location,this.map);
  }
  addMarker(position, map){

    return new google.maps.Marker({
      position,
      map
    });
  }

}
