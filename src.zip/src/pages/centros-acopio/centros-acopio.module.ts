import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CentrosAcopioPage } from './centros-acopio';

@NgModule({
  declarations: [
    CentrosAcopioPage,
  ],
  imports: [
    IonicPageModule.forChild(CentrosAcopioPage),
  ],
})
export class CentrosAcopioPageModule {}
